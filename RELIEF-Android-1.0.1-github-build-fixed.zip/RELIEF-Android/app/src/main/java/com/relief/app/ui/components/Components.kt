package com.relief.app.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.relief.app.data.local.entity.PassageEntity
import com.relief.app.data.model.AppLanguage
import com.relief.app.data.model.ScriptureType
import com.relief.app.ui.theme.CharcoalSurface
import com.relief.app.ui.theme.DeepObsidian
import com.relief.app.ui.theme.MetallicGold
import com.relief.app.ui.theme.MutedGoldBorder
import com.relief.app.ui.theme.WarmGrey
import com.relief.app.ui.theme.WarmWhite

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReliefTopBar(
    title: String,
    onBack: (() -> Unit)? = null,
    actions: @Composable () -> Unit = {}
) {
    TopAppBar(
        title = {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                color = WarmWhite,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        },
        navigationIcon = {
            if (onBack != null) {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
                        contentDescription = "Back",
                        tint = MetallicGold
                    )
                }
            }
        },
        actions = { actions() },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = DeepObsidian,
            titleContentColor = WarmWhite
        )
    )
}

@Composable
fun ReliefCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(18.dp)
    if (onClick != null) {
        Surface(
            onClick = onClick,
            modifier = modifier.fillMaxWidth(),
            shape = shape,
            color = CharcoalSurface,
            border = BorderStroke(1.dp, MutedGoldBorder)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                content = content
            )
        }
    } else {
        Surface(
            modifier = modifier.fillMaxWidth(),
            shape = shape,
            color = CharcoalSurface,
            border = BorderStroke(1.dp, MutedGoldBorder)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                content = content
            )
        }
    }
}

@Composable
fun PassageCard(
    passage: PassageEntity,
    language: AppLanguage,
    fontScale: Float,
    isBookmarked: Boolean,
    onToggleBookmark: () -> Unit,
    showTransliteration: Boolean = true,
    onOpenChapter: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val scriptureLabel = if (language == AppLanguage.HINDI) passage.scripture.displayNameHi else passage.scripture.displayNameEn
    val bookLabel = if (language == AppLanguage.HINDI && passage.bookOrSurahHindi.isNotBlank()) {
        passage.bookOrSurahHindi
    } else {
        passage.bookOrSurah
    }
    val refString = "$scriptureLabel · $bookLabel ${passage.chapterNumber}:${passage.verseNumber}"

    ReliefCard(onClick = onOpenChapter) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = refString,
                style = MaterialTheme.typography.labelMedium,
                color = MetallicGold,
                modifier = Modifier.weight(1f)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { copyPassage(context, refString, passage) }, modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Outlined.ContentCopy, contentDescription = "Copy", tint = WarmGrey, modifier = Modifier.size(18.dp))
                }
                IconButton(onClick = { sharePassage(context, refString, passage) }, modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Outlined.Share, contentDescription = "Share", tint = WarmGrey, modifier = Modifier.size(18.dp))
                }
                IconButton(onClick = onToggleBookmark, modifier = Modifier.size(40.dp)) {
                    Icon(
                        imageVector = if (isBookmarked) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                        contentDescription = "Bookmark",
                        tint = if (isBookmarked) MetallicGold else WarmGrey,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        if (passage.originalText.isNotBlank()) {
            Spacer(modifier = Modifier.height(10.dp))
            val isRtl = passage.scripture.isRtlOriginal
            CompositionLocalProvider(
                LocalLayoutDirection provides if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr
            ) {
                Text(
                    text = passage.originalText,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontSize = (20f * fontScale).sp,
                        lineHeight = (32f * fontScale).sp
                    ),
                    color = WarmWhite,
                    textAlign = if (isRtl) TextAlign.Right else TextAlign.Left,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        if (showTransliteration && passage.transliteration.isNotBlank()) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = passage.transliteration,
                style = MaterialTheme.typography.bodyMedium,
                color = WarmGrey
            )
        }

        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = if (language == AppLanguage.HINDI && passage.hindiText.isNotBlank()) {
                passage.hindiText
            } else {
                passage.englishText
            },
            style = MaterialTheme.typography.bodyLarge.copy(
                fontSize = (16f * fontScale).sp,
                lineHeight = (26f * fontScale).sp
            ),
            color = WarmWhite
        )

        val secondaryText = if (language == AppLanguage.HINDI) passage.englishText else passage.hindiText
        if (secondaryText.isNotBlank()) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = secondaryText,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontSize = (14f * fontScale).sp,
                    lineHeight = (22f * fontScale).sp
                ),
                color = WarmGrey
            )
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = "${passage.translationEdition} · ${passage.license}",
            style = MaterialTheme.typography.labelMedium,
            color = WarmGrey
        )
    }
}

private fun copyPassage(context: Context, ref: String, passage: PassageEntity) {
    val text = buildString {
        appendLine(ref)
        if (passage.originalText.isNotBlank()) appendLine(passage.originalText)
        appendLine(passage.englishText)
        if (passage.hindiText.isNotBlank()) appendLine(passage.hindiText)
        append("Source: ${passage.source}")
    }
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText(ref, text))
}

private fun sharePassage(context: Context, ref: String, passage: PassageEntity) {
    val text = "$ref\n\n${passage.originalText}\n\n${passage.englishText}\n\n${passage.hindiText}\n\n— RELIEF (${passage.source})"
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    context.startActivity(Intent.createChooser(intent, ref))
}
