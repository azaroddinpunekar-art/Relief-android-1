package com.relief.app

import com.relief.app.data.ai.OfflineGroundedWisdomAssistant
import com.relief.app.data.local.entity.PassageEntity
import com.relief.app.data.model.ScriptureType
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WisdomAssistantGuardTest {

    @Test
    fun `assistant never fabricates verses when no verified candidate exists`() = runTest {
        val assistant = OfflineGroundedWisdomAssistant(isPaidServiceEnabled = false)
        val response = assistant.answerLifeQuestion("unknown question", emptyList())
        assertTrue(response.citedPassages.isEmpty())
        assertTrue(response.comparativeExplanation.contains("will not fabricate"))
        assertFalse(response.isServiceActive)
    }

    @Test
    fun `assistant keeps paid AI disabled and cites only verified candidates`() = runTest {
        val assistant = OfflineGroundedWisdomAssistant(isPaidServiceEnabled = false)
        val sample = PassageEntity(
            id = "GITA:2:47",
            scripture = ScriptureType.GITA,
            bookNumber = 2,
            bookOrSurah = "Sankhya Yoga",
            bookOrSurahOriginal = "सांख्ययोग",
            bookOrSurahHindi = "सांख्ययोग",
            chapterNumber = 2,
            verseNumber = 47,
            originalText = "कर्मण्येवाधिकारस्ते",
            englishText = "Thy right is to work only...",
            hindiText = "तेरा कर्म करने में ही अधिकार है...",
            translationEdition = "Sivananda",
            source = "Vedic Scriptures",
            license = "GPLv3"
        )
        val response = assistant.answerLifeQuestion("anxiety", listOf(sample))
        assertFalse(response.isServiceActive)
        assertTrue(response.citedPassages.size == 1)
    }
}
