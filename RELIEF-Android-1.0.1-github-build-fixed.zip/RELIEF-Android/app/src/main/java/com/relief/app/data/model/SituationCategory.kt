package com.relief.app.data.model

data class SituationGuidanceSpec(
    val id: String,
    val titleEn: String,
    val titleHi: String,
    val subtitleEn: String,
    val subtitleHi: String,
    val passageMappings: List<SituationPassageSpec>
)

data class SituationPassageSpec(
    val passageId: String,
    val scripture: ScriptureType,
    val interpretationEn: String,
    val interpretationHi: String,
    val reflectionEn: String,
    val reflectionHi: String
)

object SituationCatalog {
    val allSituations: List<SituationGuidanceSpec> = listOf(
        SituationGuidanceSpec(
            id = "fear_anxiety",
            titleEn = "Fear and Anxiety",
            titleHi = "भय और चिंता",
            subtitleEn = "Finding stillness when uncertainty overwhelms the mind.",
            subtitleHi = "अनिश्चितता में मन को शांत और स्थिर रखने का मार्गदर्शन।",
            passageMappings = listOf(
                SituationPassageSpec(
                    passageId = "QURAN:2:286",
                    scripture = ScriptureType.QURAN,
                    interpretationEn = "Editorial Commentary: Classical Quranic exegesis reads this verse as a reminder that moral responsibility and trials are measured against human capacity, pairing effort with reliance.",
                    interpretationHi = "संपादकीय टिप्पणी: यह आयत याद दिलाती है कि जीवन की परीक्षाएँ मनुष्य की सहनशक्ति के अनुरूप होती हैं और प्रयास के साथ ईश्वर पर भरोसा जुड़ा है।",
                    reflectionEn = "Name one concrete weight you are carrying today, and separate what is within your duty from what belongs to tomorrow.",
                    reflectionHi = "आज आप जिस बोझ को महसूस कर रहे हैं, उसमें से अपने कर्तव्य और कल की चिंता को अलग करके देखें।"
                ),
                SituationPassageSpec(
                    passageId = "GITA:2:47",
                    scripture = ScriptureType.GITA,
                    interpretationEn = "Editorial Commentary: Krishna redirects Arjuna from outcome-driven dread toward focused, ethical action without paralysis over results.",
                    interpretationHi = "संपादकीय टिप्पणी: श्रीकृष्ण अर्जुन का ध्यान परिणाम के भय से हटाकर निष्काम और स्थिर कर्म की ओर मोड़ते हैं।",
                    reflectionEn = "Identify the next right step in front of you and perform it with steady attention, releasing anxiety over the distant outcome.",
                    reflectionHi = "अपने सामने का एक सही कदम चुनें और दूर के परिणाम की चिंता छोड़कर उस पर ध्यान केंद्रित करें।"
                ),
                SituationPassageSpec(
                    passageId = "BIBLE:19:23:4",
                    scripture = ScriptureType.BIBLE,
                    interpretationEn = "Editorial Commentary: Psalm 23 uses pastoral imagery of companionship through dark valleys—not the absence of danger, but the assurance of guidance.",
                    interpretationHi = "संपादकीय टिप्पणी: भजन 23 संकट की घड़ी में अकेले न होने और मार्गदर्शन के भरोसे का काव्यमय संदेश देता है।",
                    reflectionEn = "Slow your breathing and recall a difficult season you have already walked through with steadiness.",
                    reflectionHi = "गहरी सांस लें और उस कठिन समय को याद करें जिसे आप पहले भी धैर्य से पार कर चुके हैं।"
                )
            )
        ),
        SituationGuidanceSpec(
            id = "anger",
            titleEn = "Anger",
            titleHi = "क्रोध",
            subtitleEn = "Mastering reactive heat before it clouds judgment.",
            subtitleHi = "निर्णय को धुंधला होने से पहले क्रोध पर संयम पाना।",
            passageMappings = listOf(
                SituationPassageSpec(
                    passageId = "QURAN:3:134",
                    scripture = ScriptureType.QURAN,
                    interpretationEn = "Editorial Commentary: Restraining rage and pardoning people are paired together as marks of spiritual maturity and self-mastery.",
                    interpretationHi = "संपादकीय टिप्पणी: क्रोध को पी जाना और लोगों को क्षमा करना आत्म-संयम और सदाचार की पहचान बताया गया है।",
                    reflectionEn = "Pause for ten quiet breaths before speaking when provoked; strength lies in measured restraint.",
                    reflectionHi = "उत्तेजना के क्षण में बोलने से पहले दस गहरी सांसें लें; सच्ची शक्ति संयम में है।"
                ),
                SituationPassageSpec(
                    passageId = "GITA:2:63",
                    scripture = ScriptureType.GITA,
                    interpretationEn = "Editorial Commentary: The Gita traces a psychological chain from anger to delusion, memory loss, and clouded discernment.",
                    interpretationHi = "संपादकीय टिप्पणी: गीता बताती है कि क्रोध से मोह उत्पन्न होता है और विवेक नष्ट हो जाता है।",
                    reflectionEn = "Notice the physical signs of rising anger early, before your clarity of judgment narrows.",
                    reflectionHi = "विवेक खोने से पहले ही अपने भीतर उठते क्रोध के संकेतों को पहचानें।"
                ),
                SituationPassageSpec(
                    passageId = "BIBLE:20:15:1",
                    scripture = ScriptureType.BIBLE,
                    interpretationEn = "Editorial Commentary: Proverbs contrasts a measured, gentle reply with harsh speech that escalates conflict.",
                    interpretationHi = "संपादकीय टिप्पणी: नीतिवचन सिखाता है कि कोमल उत्तर क्रोध को शांत करता है जबकि कठोर वचन आग भड़काते हैं।",
                    reflectionEn = "Choose a calm tone today even when addressing a genuine grievance.",
                    reflectionHi = "अपनी वास्तविक बात रखते हुए भी आज शांत और संतुलित स्वर चुनें।"
                )
            )
        ),
        SituationGuidanceSpec(
            id = "betrayal_manipulation",
            titleEn = "Betrayal and Manipulation",
            titleHi = "विश्वासघात और छल",
            subtitleEn = "Preserving integrity and discernment when trust is broken.",
            subtitleHi = "विश्वास टूटने पर विवेक और नैतिक दृढ़ता बनाए रखना।",
            passageMappings = listOf(
                SituationPassageSpec("QURAN:4:135", ScriptureType.QURAN, "Editorial Commentary: Standing firm for justice and truth even when personal ties or pressures tempt compromise.", "संपादकीय टिप्पणी: कठिन परिस्थितियों में भी न्याय और सत्य पर अडिग रहने का निर्देश।", "Do not mirror deceit with deceit; protect your boundaries with honesty.", "छल का उत्तर छल से न दें; ईमानदारी से अपनी सीमाएँ सुरक्षित रखें।"),
                SituationPassageSpec("GITA:16:2", ScriptureType.GITA, "Editorial Commentary: Truthfulness, absence of malice, and steadiness of heart define ethical nobility.", "संपादकीय टिप्पणी: सत्य, अक्रोध और छल-रहित आचरण को दैवीय गुणों में गिना गया है।", "Separate your self-worth from someone else's breach of trust.", "किसी अन्य के विश्वासघात से अपने आत्मसम्मान को परिभाषित न होने दें।"),
                SituationPassageSpec("BIBLE:19:55:22", ScriptureType.BIBLE, "Editorial Commentary: Written amid personal betrayal in Psalm 55, this verse counsels steadiness rather than collapse.", "संपादकीय टिप्पणी: निकट मित्र के विश्वासघात के संदर्भ में रचा गया यह भजन धैर्य और सहारे की प्रेरणा देता है।", "Seek wise counsel and clear boundaries while refusing bitterness.", "कड़वाहट से बचते हुए स्पष्ट सीमाएँ तय करें और विवेकपूर्ण सलाह लें।")
            )
        ),
        SituationGuidanceSpec(
            id = "relationships",
            titleEn = "Relationships",
            titleHi = "संबंध",
            subtitleEn = "Cultivating empathy, respect, and truthfulness with others.",
            subtitleHi = "रिश्तों में सहानुभूति, सम्मान और सत्यनिष्ठा का अभ्यास।",
            passageMappings = listOf(
                SituationPassageSpec("QURAN:49:11", ScriptureType.QURAN, "Editorial Commentary: Warns against mockery, defamation, and demeaning labels that fracture community bonds.", "संपादकीय टिप्पणी: उपहास, अपमान और कटु नामों से बचने की शिक्षा जो संबंधों को तोड़ते हैं।", "Listen to understand rather than to score a point in your closest conversation today.", "आज किसी अपने से बात करते समय जीतने के बजाय समझने के लिए सुनें।"),
                SituationPassageSpec("GITA:12:13", ScriptureType.GITA, "Editorial Commentary: Compassion and friendliness toward all beings without egoistic attachment.", "संपादकीय टिप्पणी: सभी प्राणियों के प्रति मित्रता, करुणा और अहंकार-रहित भाव का आदर्श।", "Offer kindness without keeping a ledger of grievances.", "शिकायतों का हिसाब रखे बिना सरल करुणा का व्यवहार करें।"),
                SituationPassageSpec("BIBLE:46:13:4", ScriptureType.BIBLE, "Editorial Commentary: Defines love through active patience, humility, and refusal to boast or resent.", "संपादकीय टिप्पणी: प्रेम को धैर्य, दया और विनम्र आचरण के रूप में परिभाषित किया गया है।", "Practice one unprompted act of patience toward someone close to you.", "आज किसी प्रियजन के प्रति धैर्य का एक शांत उदाहरण प्रस्तुत करें।")
            )
        ),
        SituationGuidanceSpec(
            id = "financial_struggles",
            titleEn = "Financial Struggles",
            titleHi = "आर्थिक संकट",
            subtitleEn = "Maintaining dignity, prudence, and resilience in scarcity.",
            subtitleHi = "आर्थिक तंगी में आत्मसम्मान, विवेक और धैर्य बनाए रखना।",
            passageMappings = listOf(
                SituationPassageSpec("QURAN:65:3", ScriptureType.QURAN, "Editorial Commentary: Encourages trust alongside lawful effort when provision feels uncertain.", "संपादकीय टिप्पणी: अनिश्चित समय में ईमानदार प्रयास के साथ धैर्य और भरोसे का संदेश।", "Focus on steady daily discipline and honest work over panic.", "घबराहट के बजाय नियमित परिश्रम और ईमानदार प्रयास पर ध्यान दें।"),
                SituationPassageSpec("GITA:9:22", ScriptureType.GITA, "Editorial Commentary: Speaks of steadiness in devotion and freedom from obsessive scarcity anxiety.", "संपादकीय टिप्पणी: अनन्य निष्ठा और स्थिर चित्त के साथ आवश्यकताओं के निर्वाह का आश्वासन।", "Distinguish essential needs from comparison-driven pressures.", "आवश्यकताओं और सामाजिक तुलना से उपजे दबाव में अंतर करें।"),
                SituationPassageSpec("BIBLE:40:6:34", ScriptureType.BIBLE, "Editorial Commentary: Advises meeting today's practical responsibilities without borrowing tomorrow's dread.", "संपादकीय टिप्पणी: कल की चिंता से बोझिल होने के बजाय आज के कर्तव्य पर ध्यान देने की सीख।", "Create one small, concrete budget or outreach step for today only.", "केवल आज के लिए एक छोटा और व्यावहारिक आर्थिक कदम तय करें।")
            )
        ),
        SituationGuidanceSpec(
            id = "loneliness",
            titleEn = "Loneliness",
            titleHi = "अकेलापन",
            subtitleEn = "Transforming isolation into quiet presence and connection.",
            subtitleHi = "एकाकीपन को आंतरिक उपस्थिति और सार्थक जुड़ाव में बदलना।",
            passageMappings = listOf(
                SituationPassageSpec("QURAN:50:16", ScriptureType.QURAN, "Editorial Commentary: Expresses profound nearness to the inner self, countering existential solitude.", "संपादकीय टिप्पणी: मनुष्य के अंतर्मन के अत्यंत निकट होने का बोध, जो एकाकीपन को शांत करता है।", "Reach out to one person thoughtfully today, and treat quiet hours as restorative rather than empty.", "आज किसी एक व्यक्ति से संवाद करें और शांत समय को विश्राम के रूप में अपनाएँ।"),
                SituationPassageSpec("GITA:6:29", ScriptureType.GITA, "Editorial Commentary: Sees interconnectedness across all beings through a harmonized mind.", "संपादकीय टिप्पणी: समदर्शी बुद्धि के माध्यम से सभी में एकात्मता का अनुभव।", "Participate in a small act of service to bridge isolation.", "अकेलापन कम करने के लिए किसी छोटे सेवा-कार्य में भाग लें।"),
                SituationPassageSpec("BIBLE:19:27:10", ScriptureType.BIBLE, "Editorial Commentary: Reassures the reader that abandonment by human circles is not the final word on belonging.", "संपादकीय टिप्पणी: मानवीय उपेक्षा के बीच भी आत्मीय सहारे का भरोसा दिलाता है।", "Allow yourself honest companionship without masking your fatigue.", "अपनी थकान छिपाए बिना किसी विश्वसनीय व्यक्ति से सहज संवाद करें।")
            )
        ),
        SituationGuidanceSpec(
            id = "grief_loss",
            titleEn = "Grief and Loss",
            titleHi = "शोक और हानि",
            subtitleEn = "Honoring sorrow with patience, dignity, and remembrance.",
            subtitleHi = "दुख और वियोग को धैर्य और गरिमा के साथ सहना।",
            passageMappings = listOf(
                SituationPassageSpec("QURAN:2:156", ScriptureType.QURAN, "Editorial Commentary: Spoken in bereavement as an acknowledgment of return, patience, and belonging.", "संपादकीय टिप्पणी: शोक की घड़ी में धैर्य और जीवन की नश्वरता को स्वीकारने का वचन।", "Give yourself permission to grieve honestly without rushing false cheerfulness.", "बनावटी प्रसन्नता का दबाव डाले बिना अपने शोक को ईमानदारी से स्वीकार करें।"),
                SituationPassageSpec("GITA:2:20", ScriptureType.GITA, "Editorial Commentary: Frames the enduring essence beyond physical dissolution to console profound sorrow.", "संपादकीय टिप्पणी: गहन शोक के समय आत्मा की अमरता का दार्शनिक सांत्वना-बोध।", "Honor what you loved through how you live gently today.", "आज के शांत और संवेदनशील आचरण से अपने प्रिय की स्मृति का सम्मान करें।"),
                SituationPassageSpec("BIBLE:19:34:18", ScriptureType.BIBLE, "Editorial Commentary: Affirms nearness to the brokenhearted rather than demanding stoic numbness.", "संपादकीय टिप्पणी: टूटे हुए मन के प्रति संवेदनशील निकटता का संदेश।", "Let grief take its measured time alongside supportive community.", "सहायक लोगों के बीच रहकर शोक को स्वाभाविक समय दें।")
            )
        ),
        SituationGuidanceSpec(
            id = "forgiveness",
            titleEn = "Forgiveness",
            titleHi = "क्षमा",
            subtitleEn = "Releasing resentment without excusing harm.",
            subtitleHi = "अन्याय को सही ठहराए बिना मन की कड़वाहट छोड़ना।",
            passageMappings = listOf(
                SituationPassageSpec("QURAN:42:40", ScriptureType.QURAN, "Editorial Commentary: Recognizes proportional justice while elevating reconciliation and pardon.", "संपादकीय टिप्पणी: न्याय के अधिकार को मानते हुए भी क्षमा और सुधार को श्रेष्ठ बताया गया है।", "Forgiveness releases your own heart from replaying the wound.", "क्षमा आपके अपने मन को बार-बार आहत होने से मुक्त करती है।"),
                SituationPassageSpec("GITA:16:3", ScriptureType.GITA, "Editorial Commentary: Places forbearance (kshama) among core virtues of steadiness and clarity.", "संपादकीय टिप्पणी: क्षमा और धैर्य को चरित्र के प्रमुख सद्गुणों में गिना गया है।", "Choose not to carry yesterday's bitterness into today's clarity.", "कल की कड़वाहट को आज के शांत चित्त पर हावी न होने दें।"),
                SituationPassageSpec("BIBLE:51:3:13", ScriptureType.BIBLE, "Editorial Commentary: Counsels mutual forbearance and letting go of lingering grudges.", "संपादकीय टिप्पणी: आपसी सहनशीलता और शिकायतों को छोड़कर क्षमा करने की शिक्षा।", "Distinguish releasing resentment from rebuilding unearned trust.", "मन से द्वेष छोड़ने और विश्वास पुनः बनाने के बीच का अंतर समझें।")
            )
        ),
        SituationGuidanceSpec(
            id = "patience",
            titleEn = "Patience",
            titleHi = "धैर्य",
            subtitleEn = "Enduring slow seasons with steady character.",
            subtitleHi = "कठिन और धीमे समय में स्थिर चरित्र बनाए रखना।",
            passageMappings = listOf(
                SituationPassageSpec("QURAN:94:5", ScriptureType.QURAN, "Editorial Commentary: Pairs hardship directly with ease as a recurring law of lived experience.", "संपादकीय टिप्पणी: कठिनाई के साथ ही सहजता और राहत के जुड़े होने का आश्वासन।", "Stay faithful to small daily routines while waiting for change.", "बदलाव की प्रतीक्षा में छोटे-छोटे दैनिक नियमों पर टिके रहें।"),
                SituationPassageSpec("GITA:2:14", ScriptureType.GITA, "Editorial Commentary: Compares shifting joys and sorrows to passing seasons that call for endurance.", "संपादकीय टिप्पणी: सुख-दुख को बदलते मौसमों की तरह अस्थायी मानकर सहनशीलता का उपदेश।", "Remind yourself that intense feelings are weather, not permanent architecture.", "स्वयं को याद दिलाएँ कि तीव्र भावनाएँ मौसम की तरह हैं, स्थायी नहीं।"),
                SituationPassageSpec("BIBLE:59:1:4", ScriptureType.BIBLE, "Editorial Commentary: Treats steadfastness as a builder of mature, whole character.", "संपादकीय टिप्पणी: धैर्य को परिपक्व और संतुलित व्यक्तित्व के निर्माण का आधार बताया गया है।", "Measure progress in steadiness rather than speed.", "प्रगति को गति से नहीं, अपनी स्थिरता से मापें।")
            )
        ),
        SituationGuidanceSpec(
            id = "jealousy",
            titleEn = "Jealousy",
            titleHi = "ईर्ष्या",
            subtitleEn = "Turning comparison into gratitude and focused purpose.",
            subtitleHi = "तुलना और जलन को कृतज्ञता और स्वधर्म में बदलना।",
            passageMappings = listOf(
                SituationPassageSpec("QURAN:4:32", ScriptureType.QURAN, "Editorial Commentary: Counsels against coveting what others have been allotted, redirecting toward gratitude.", "संपादकीय टिप्पणी: दूसरों को मिले अवसरों की ईर्ष्या छोड़कर अपने परिश्रम और कृतज्ञता पर ध्यान देने की सीख।", "List three things in your own path that you would not trade away.", "अपने जीवन की तीन ऐसी बातें लिखें जिनके लिए आप कृतज्ञ हैं।"),
                SituationPassageSpec("GITA:12:13", ScriptureType.GITA, "Editorial Commentary: Names freedom from envy and ego as the foundation of inner peace.", "संपादकीय टिप्पणी: द्वेष और ईर्ष्या से मुक्ति को मानसिक शांति का आधार कहा गया है।", "Acknowledge someone else's good fortune without shrinking your own worth.", "किसी अन्य की सफलता को स्वीकारते हुए अपनी योग्यता को कम न आँकें।"),
                SituationPassageSpec("BIBLE:20:14:30", ScriptureType.BIBLE, "Editorial Commentary: Contrasts a tranquil heart with envy that corrodes vitality from within.", "संपादकीय टिप्पणी: शांत मन को जीवनदायक और ईर्ष्या को भीतर से क्षय करने वाला बताया गया है।", "Step back from comparison feeds and invest an hour in your own craft.", "तुलना से दूर हटकर अपने कौशल या कर्तव्य को एक शांत घंटा दें।")
            )
        ),
        SituationGuidanceSpec(
            id = "failure",
            titleEn = "Failure",
            titleHi = "असफलता",
            subtitleEn = "Learning from setbacks without surrendering hope.",
            subtitleHi = "पराजय से सीखकर आशा और प्रयास को फिर से जागृत करना।",
            passageMappings = listOf(
                SituationPassageSpec("QURAN:39:53", ScriptureType.QURAN, "Editorial Commentary: Calls against despair after mistakes, opening the door to renewal.", "संपादकीय टिप्पणी: त्रुटियों या असफलता के बाद निराश न होने और नए आरंभ का संदेश।", "Treat a setback as data for your next effort, not a verdict on your future.", "असफलता को अपने भविष्य का अंतिम निर्णय नहीं, अगले प्रयास का पाठ मानें।"),
                SituationPassageSpec("GITA:6:5", ScriptureType.GITA, "Editorial Commentary: Urges lifting oneself by one's own steady mind rather than sinking into self-condemnation.", "संपादकीय टिप्पणी: आत्म-ग्लानि में डूबने के बजाय स्वयं अपने मन से स्वयं का उत्थान करने का उपदेश।", "Be a firm, constructive friend to yourself after a hard mistake.", "गलती के बाद स्वयं के आलोचक नहीं, एक ईमानदार मार्गदर्शक बनें।"),
                SituationPassageSpec("BIBLE:20:24:16", ScriptureType.BIBLE, "Editorial Commentary: Observes that resilience is defined by rising again after falling.", "संपादकीय टिप्पणी: गिरकर फिर उठ खड़े होने की क्षमता को ही सच्ची दृढ़ता बताया गया है।", "Identify one lesson from the setback and take one modest step forward today.", "इस अनुभव से एक सीख चुनें और आज एक छोटा कदम आगे बढ़ाएँ।")
            )
        ),
        SituationGuidanceSpec(
            id = "purpose_life",
            titleEn = "Purpose in Life",
            titleHi = "जीवन का उद्देश्य",
            subtitleEn = "Aligning daily work with meaning, duty, and service.",
            subtitleHi = "दैनिक कर्म को अर्थ, कर्तव्य और सेवा से जोड़ना।",
            passageMappings = listOf(
                SituationPassageSpec("QURAN:51:56", ScriptureType.QURAN, "Editorial Commentary: Grounds human existence in mindful reverence and purposeful stewardship.", "संपादकीय टिप्पणी: जीवन को सचेत उद्देश्य और सार्थक उत्तरदायित्व से जोड़ने का संदर्भ।", "Ask who benefits when your daily work is done faithfully.", "सोचें कि जब आप अपना काम निष्ठा से करते हैं तो किसका भला होता है।"),
                SituationPassageSpec("GITA:3:19", ScriptureType.GITA, "Editorial Commentary: Connects unattached, conscientious duty with inner clarity and contribution.", "संपादकीय टिप्पणी: आसक्ति-रहित होकर अपना कर्तव्य निभाने को ही श्रेष्ठ मार्ग बताया गया है।", "Do ordinary duties with extraordinary care.", "साधारण कर्तव्यों को भी पूरी निष्ठा और सावधानी से निभाएँ।"),
                SituationPassageSpec("BIBLE:33:6:8", ScriptureType.BIBLE, "Editorial Commentary: Summarizes purposeful living in three clear practices: justice, mercy, and humility.", "संपादकीय टिप्पणी: न्याय, दया और विनम्रता को सार्थक जीवन के तीन स्तंभ बताया गया है।", "Evaluate today's schedule by fairness, kindness, and humility.", "आज की दिनचर्या को न्याय, करुणा और विनम्रता की कसौटी पर देखें।")
            )
        ),
        SituationGuidanceSpec(
            id = "self_control",
            titleEn = "Self-Control",
            titleHi = "आत्म-संयम",
            subtitleEn = "Guiding impulses through discipline and awareness.",
            subtitleHi = "आवेगों को अनुशासन और सजगता से साधना।",
            passageMappings = listOf(
                SituationPassageSpec("QURAN:79:40", ScriptureType.QURAN, "Editorial Commentary: Links restraining unruly impulse with lasting inner peace.", "संपादकीय टिप्पणी: मन की अनियंत्रित इच्छाओं पर संयम रखने को स्थायी शांति से जोड़ा गया है।", "Practice saying a calm 'not now' to one distracting habit today.", "आज किसी एक भटकाने वाली आदत को शांत भाव से 'अभी नहीं' कहें।"),
                SituationPassageSpec("GITA:6:26", ScriptureType.GITA, "Editorial Commentary: Advises gently guiding the wandering mind back whenever it drifts.", "संपादकीय टिप्पणी: चंचल मन को जहाँ-जहाँ भटके वहाँ से धैर्यपूर्वक वापस लाने का अभ्यास।", "Self-control is gentle redirection, repeated without harshness.", "आत्म-संयम कठोरता नहीं, बार-बार शांत भाव से ध्यान लौटाने का अभ्यास है।"),
                SituationPassageSpec("BIBLE:20:25:28", ScriptureType.BIBLE, "Editorial Commentary: Compares lacking self-restraint to an unguarded city without walls.", "संपादकीय टिप्पणी: आत्म-संयम के बिना जीवन को बिना चारदीवारी के नगर जैसा असुरक्षित बताया गया है।", "Protect your attention boundaries before fatigue weakens your resolve.", "थकान हावी होने से पहले ही अपने ध्यान की सीमाएँ सुरक्षित रखें।")
            )
        ),
        SituationGuidanceSpec(
            id = "honesty_integrity",
            titleEn = "Honesty and Integrity",
            titleHi = "ईमानदारी और सत्यनिष्ठा",
            subtitleEn = "Living transparently when compromise looks easier.",
            subtitleHi = "सुविधा के प्रलोभन में भी सत्य और पारदर्शिता पर टिके रहना।",
            passageMappings = listOf(
                SituationPassageSpec("QURAN:9:119", ScriptureType.QURAN, "Editorial Commentary: Commands truthfulness in speech, intention, and companionship.", "संपादकीय टिप्पणी: वाणी, नीयत और संगति में सत्यनिष्ठा बनाए रखने का निर्देश।", "Keep private promises as strictly as public agreements.", "निजी वादों का भी उतनी ही दृढ़ता से पालन करें जितना सार्वजनिक समझौतों का।"),
                SituationPassageSpec("GITA:17:15", ScriptureType.GITA, "Editorial Commentary: Defines disciplined speech as truthful, beneficial, non-harming, and calm.", "संपादकीय टिप्पणी: सत्य, प्रिय, हितकारी और उद्वेग-रहित वाणी को वाक्-तप कहा गया है।", "Let your words be both accurate and humane.", "आपकी बात सत्य होने के साथ-साथ संवेदनशील भी हो।"),
                SituationPassageSpec("BIBLE:20:10:9", ScriptureType.BIBLE, "Editorial Commentary: Associates walking in integrity with steady security over crooked shortcuts.", "संपादकीय टिप्पणी: ईमानदारी के मार्ग पर चलने को स्थायी सुरक्षा और शांति का आधार बताया गया है।", "Refuse small compromises that erode self-respect.", "छोटे-छोटे अनुचित समझौतों से बचें जो आत्मसम्मान को कमजोर करते हैं।")
            )
        ),
        SituationGuidanceSpec(
            id = "moral_conflicts",
            titleEn = "Moral Conflicts",
            titleHi = "नैतिक द्वंद्व",
            subtitleEn = "Choosing principle over convenience in hard dilemmas.",
            subtitleHi = "कठिन दुविधा में सुविधा के बजाय सिद्धांत और विवेक को चुनना।",
            passageMappings = listOf(
                SituationPassageSpec("QURAN:5:8", ScriptureType.QURAN, "Editorial Commentary: Forbids letting hostility toward anyone sway you away from fairness.", "संपादकीय टिप्पणी: किसी के प्रति द्वेष के कारण न्याय से न भटकने की स्पष्ट चेतावनी।", "Test your decision by asking whether it remains fair if roles were reversed.", "निर्णय लेते समय सोचें कि यदि भूमिकाएँ बदल जाएँ तो क्या यह निर्णय न्यायसंगत रहेगा।"),
                SituationPassageSpec("GITA:18:63", ScriptureType.GITA, "Editorial Commentary: Invites deep reflection before choosing freely with moral responsibility.", "संपादकीय टिप्पणी: संपूर्ण ज्ञान सुनकर गहराई से विचार करने के बाद स्वतंत्र विवेक से निर्णय लेने का आह्वान।", "Slow down major moral choices until conscience and clarity align.", "बड़े नैतिक निर्णयों को तब तक न लें जब तक विवेक और स्पष्टता एक न हों।"),
                SituationPassageSpec("BIBLE:59:3:17", ScriptureType.BIBLE, "Editorial Commentary: Characterizes moral wisdom as peaceable, considerate, impartial, and sincere.", "संपादकीय टिप्पणी: सच्चे विवेक को निष्पक्ष, शांत, विचारशील और कपट-रहित बताया गया है।", "Seek solutions rooted in fairness and sincerity rather than ego.", "अहंकार के बजाय निष्पक्षता और ईमानदारी पर आधारित समाधान खोजें।")
            )
        )
    )
}
