package com.relief.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoStories
import androidx.compose.material.icons.outlined.CompareArrows
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.relief.app.data.local.entity.ImportAuditEntity
import com.relief.app.data.local.entity.PassageEntity
import com.relief.app.data.model.AppLanguage
import com.relief.app.data.model.SituationGuidanceSpec
import com.relief.app.ui.components.PassageCard
import com.relief.app.ui.components.ReliefCard
import com.relief.app.ui.theme.CharcoalSurface
import com.relief.app.ui.theme.DeepObsidian
import com.relief.app.ui.theme.MetallicGold
import com.relief.app.ui.theme.MutedGoldBorder
import com.relief.app.ui.theme.WarmGrey
import com.relief.app.ui.theme.WarmWhite
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(onFinished: () -> Unit) {
    LaunchedEffect(Unit) {
        delay(1200)
        onFinished()
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepObsidian)
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Surface(
                modifier = Modifier.size(88.dp),
                shape = CircleShape,
                color = CharcoalSurface,
                border = BorderStroke(1.dp, MetallicGold)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text("R", style = MaterialTheme.typography.displayLarge, color = MetallicGold)
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "RELIEF",
                style = MaterialTheme.typography.displayLarge,
                color = WarmWhite
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Wisdom for Life's Struggles",
                style = MaterialTheme.typography.bodyMedium,
                color = WarmGrey,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun WelcomeScreen(
    language: AppLanguage,
    onContinue: () -> Unit
) {
    val isHi = language == AppLanguage.HINDI
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepObsidian)
            .padding(28.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Spacer(modifier = Modifier.height(24.dp))
        Column {
            Text(
                text = "RELIEF",
                style = MaterialTheme.typography.labelMedium,
                color = MetallicGold
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = if (isHi) "जीवन के संघर्षों के लिए प्रामाणिक विवेक" else "Verified Wisdom for Life's Struggles",
                style = MaterialTheme.typography.displayLarge,
                color = WarmWhite
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = if (isHi) {
                    "क़ुरआन, भगवद्गीता और बाइबिल से मूल पाठ, सटीक अनुवाद और व्यावहारिक चिंतन एक शांत स्थान पर पढ़ें।"
                } else {
                    "Read original passages, verified English & Hindi translations, and thoughtful guidance from the Quran, Bhagavad Gita, and Bible in one calm sanctuary."
                },
                style = MaterialTheme.typography.bodyLarge,
                color = WarmGrey
            )
        }

        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(
                onClick = onContinue,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MetallicGold, contentColor = DeepObsidian)
            ) {
                Text(
                    text = if (isHi) "प्रारंभ करें" else "Enter Sanctuary",
                    style = MaterialTheme.typography.titleMedium
                )
            }
        }
    }
}

@Composable
fun LanguageSelectorScreen(
    selectedLanguage: AppLanguage,
    onSelectLanguage: (AppLanguage) -> Unit,
    onContinue: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepObsidian)
            .padding(28.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.padding(top = 36.dp)) {
            Text("LANGUAGE · भाषा", style = MaterialTheme.typography.labelMedium, color = MetallicGold)
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Choose your preferred reading language",
                style = MaterialTheme.typography.headlineMedium,
                color = WarmWhite
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "अपनी पसंदीदा पठन भाषा चुनें। आप इसे कभी भी प्रोफ़ाइल में बदल सकते हैं।",
                style = MaterialTheme.typography.bodyMedium,
                color = WarmGrey
            )
            Spacer(modifier = Modifier.height(28.dp))

            AppLanguage.entries.forEach { lang ->
                val isSelected = lang == selectedLanguage
                Surface(
                    onClick = { onSelectLanguage(lang) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = CharcoalSurface,
                    border = BorderStroke(1.dp, if (isSelected) MetallicGold else MutedGoldBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(20.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(lang.nativeLabel, style = MaterialTheme.typography.titleLarge, color = WarmWhite)
                            Text(lang.label, style = MaterialTheme.typography.bodyMedium, color = WarmGrey)
                        }
                        if (isSelected) {
                            Text("Selected", style = MaterialTheme.typography.labelMedium, color = MetallicGold)
                        }
                    }
                }
            }
        }

        Button(
            onClick = onContinue,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MetallicGold, contentColor = DeepObsidian)
        ) {
            Text(
                text = if (selectedLanguage == AppLanguage.HINDI) "आगे बढ़ें" else "Continue",
                style = MaterialTheme.typography.titleMedium
            )
        }
    }
}

@Composable
fun HomeDashboardScreen(
    language: AppLanguage,
    fontScale: Float,
    dailyWisdom: PassageEntity?,
    bookmarkIds: List<String>,
    situations: List<SituationGuidanceSpec>,
    audits: List<ImportAuditEntity>,
    onToggleBookmark: (String) -> Unit,
    onOpenSearch: () -> Unit,
    onOpenHistory: () -> Unit,
    onOpenScriptures: () -> Unit,
    onOpenSituation: (String) -> Unit,
    onOpenComparison: (String) -> Unit,
    onOpenAbout: () -> Unit
) {
    val isHi = language == AppLanguage.HINDI
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepObsidian),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("RELIEF", style = MaterialTheme.typography.labelMedium, color = MetallicGold)
                    Text(
                        text = if (isHi) "दैनिक चिंतन" else "Daily Sanctuary",
                        style = MaterialTheme.typography.headlineMedium,
                        color = WarmWhite
                    )
                }
                Row {
                    IconButton(onClick = onOpenSearch) {
                        Icon(Icons.Outlined.Search, contentDescription = "Search", tint = MetallicGold)
                    }
                    IconButton(onClick = onOpenHistory) {
                        Icon(Icons.Outlined.History, contentDescription = "History", tint = WarmGrey)
                    }
                }
            }
        }

        item {
            if (dailyWisdom != null) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = if (isHi) "आज का वचन" else "Daily Wisdom",
                        style = MaterialTheme.typography.titleMedium,
                        color = MetallicGold
                    )
                    PassageCard(
                        passage = dailyWisdom,
                        language = language,
                        fontScale = fontScale,
                        isBookmarked = bookmarkIds.contains(dailyWisdom.id),
                        onToggleBookmark = { onToggleBookmark(dailyWisdom.id) }
                    )
                }
            } else {
                ReliefCard(onClick = onOpenAbout) {
                    Text(
                        text = if (isHi) "ऑफ़लाइन ग्रंथ डेटासेट प्रतीक्षित" else "Offline Scripture Dataset Pending",
                        style = MaterialTheme.typography.titleMedium,
                        color = MetallicGold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (isHi) {
                            "RELIEF बिना सत्यापित डेटा के उद्धरण गढ़ता नहीं है। डेटासेट स्थिति देखने या आयात करने के लिए टैप करें।"
                        } else {
                            "RELIEF never fabricates quotations. Import verified Quran, Bhagavad Gita, and Bible datasets in Profile or tap to view source status."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = WarmGrey
                    )
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onOpenScriptures,
                    modifier = Modifier.weight(1f),
                    border = BorderStroke(1.dp, MutedGoldBorder)
                ) {
                    Icon(Icons.Outlined.AutoStories, contentDescription = null, tint = MetallicGold, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.size(8.dp))
                    Text(if (isHi) "ग्रंथ पढ़ें" else "Scriptures", color = WarmWhite)
                }
                OutlinedButton(
                    onClick = { onOpenComparison("fear_anxiety") },
                    modifier = Modifier.weight(1f),
                    border = BorderStroke(1.dp, MutedGoldBorder)
                ) {
                    Icon(Icons.Outlined.CompareArrows, contentDescription = null, tint = MetallicGold, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.size(8.dp))
                    Text(if (isHi) "तुलना करें" else "Compare", color = WarmWhite)
                }
            }
        }

        item {
            Text(
                text = if (isHi) "जीवन की परिस्थितियाँ" else "Life Situations",
                style = MaterialTheme.typography.titleLarge,
                color = WarmWhite
            )
            Spacer(modifier = Modifier.height(10.dp))
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                situations.take(5).forEach { spec ->
                    ReliefCard(onClick = { onOpenSituation(spec.id) }) {
                        Text(
                            text = if (isHi) spec.titleHi else spec.titleEn,
                            style = MaterialTheme.typography.titleMedium,
                            color = WarmWhite
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isHi) spec.subtitleHi else spec.subtitleEn,
                            style = MaterialTheme.typography.bodyMedium,
                            color = WarmGrey
                        )
                    }
                }
            }
        }

        if (audits.isNotEmpty()) {
            item {
                ReliefCard(onClick = onOpenAbout) {
                    Text(
                        text = if (isHi) "डेटासेट सत्यापन सारांश" else "Dataset Verification Status",
                        style = MaterialTheme.typography.titleMedium,
                        color = MetallicGold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    audits.forEach { audit ->
                        Text(
                            text = "${audit.scripture.displayNameEn}: ${audit.importedPassages}/${audit.expectedPassages} (${if (audit.isComplete) "Verified" else "Incomplete"})",
                            style = MaterialTheme.typography.bodyMedium,
                            color = WarmGrey
                        )
                    }
                }
            }
        }
    }
}
