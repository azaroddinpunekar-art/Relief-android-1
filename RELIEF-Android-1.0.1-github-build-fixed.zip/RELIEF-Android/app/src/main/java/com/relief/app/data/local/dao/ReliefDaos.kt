package com.relief.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.relief.app.data.local.entity.BookEntity
import com.relief.app.data.local.entity.BookmarkEntity
import com.relief.app.data.local.entity.ImportAuditEntity
import com.relief.app.data.local.entity.PassageEntity
import com.relief.app.data.local.entity.ReadingHistoryEntity
import com.relief.app.data.model.ScriptureType
import kotlinx.coroutines.flow.Flow

@Dao
interface PassageDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertBooks(books: List<BookEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertPassages(passages: List<PassageEntity>): List<Long>

    @Query("SELECT * FROM books WHERE scripture = :scripture ORDER BY bookNumber ASC")
    fun observeBooks(scripture: ScriptureType): Flow<List<BookEntity>>

    @Query(
        "SELECT * FROM passages WHERE scripture = :scripture AND bookNumber = :bookNumber AND chapterNumber = :chapterNumber ORDER BY verseNumber ASC"
    )
    fun observeChapterPassages(
        scripture: ScriptureType,
        bookNumber: Int,
        chapterNumber: Int
    ): Flow<List<PassageEntity>>

    @Query("SELECT * FROM passages WHERE id = :id LIMIT 1")
    suspend fun getPassageById(id: String): PassageEntity?

    @Query("SELECT * FROM passages WHERE id IN (:ids)")
    suspend fun getPassagesByIds(ids: List<String>): List<PassageEntity>

    @Query("SELECT COUNT(*) FROM passages WHERE scripture = :scripture")
    suspend fun countByScripture(scripture: ScriptureType): Int

    @Query("SELECT COUNT(*) FROM passages")
    suspend fun countAll(): Int

    @Query(
        """
        SELECT * FROM passages
        WHERE (:scripture IS NULL OR scripture = :scripture)
          AND (
            englishText LIKE '%' || :query || '%'
            OR hindiText LIKE '%' || :query || '%'
            OR originalText LIKE '%' || :query || '%'
            OR bookOrSurah LIKE '%' || :query || '%'
            OR bookOrSurahHindi LIKE '%' || :query || '%'
            OR id LIKE '%' || :query || '%'
          )
        ORDER BY scripture ASC, bookNumber ASC, chapterNumber ASC, verseNumber ASC
        LIMIT 100
        """
    )
    suspend fun searchPassages(query: String, scripture: ScriptureType?): List<PassageEntity>

    @Query("SELECT * FROM passages ORDER BY id ASC LIMIT 1 OFFSET :offset")
    suspend fun getPassageAtOffset(offset: Int): PassageEntity?
}

@Dao
interface BookmarkDao {
    @Query(
        """
        SELECT p.* FROM passages p
        INNER JOIN bookmarks b ON p.id = b.passageId
        ORDER BY b.createdAtEpochMs DESC
        """
    )
    fun observeBookmarkedPassages(): Flow<List<PassageEntity>>

    @Query("SELECT passageId FROM bookmarks")
    fun observeBookmarkIds(): Flow<List<String>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBookmark(bookmark: BookmarkEntity)

    @Query("DELETE FROM bookmarks WHERE passageId = :passageId")
    suspend fun deleteBookmark(passageId: String)

    @Query("SELECT EXISTS(SELECT 1 FROM bookmarks WHERE passageId = :passageId)")
    suspend fun isBookmarked(passageId: String): Boolean
}

@Dao
interface HistoryDao {
    @Query(
        """
        SELECT p.* FROM passages p
        INNER JOIN reading_history h ON p.id = h.passageId
        ORDER BY h.viewedAtEpochMs DESC
        LIMIT 50
        """
    )
    fun observeRecentPassages(): Flow<List<PassageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun recordView(entry: ReadingHistoryEntity)

    @Query("DELETE FROM reading_history")
    suspend fun clearHistory()
}

@Dao
interface ImportAuditDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAudit(audit: ImportAuditEntity)

    @Query("SELECT * FROM import_audits ORDER BY scripture ASC")
    fun observeAudits(): Flow<List<ImportAuditEntity>>
}
