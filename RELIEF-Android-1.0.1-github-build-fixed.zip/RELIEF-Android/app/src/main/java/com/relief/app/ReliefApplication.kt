package com.relief.app

import android.app.Application
import com.relief.app.data.local.ReliefDatabase
import com.relief.app.data.preferences.UserPreferencesRepository
import com.relief.app.data.repository.ReliefRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class ReliefApplication : Application() {
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    lateinit var database: ReliefDatabase
        private set
    lateinit var preferencesRepository: UserPreferencesRepository
        private set
    lateinit var reliefRepository: ReliefRepository
        private set

    override fun onCreate() {
        super.onCreate()
        database = ReliefDatabase.getInstance(this)
        preferencesRepository = UserPreferencesRepository(this)
        reliefRepository = ReliefRepository(this, database)
        appScope.launch {
            reliefRepository.initializeBundledDatasetsIfPresent()
        }
    }
}
