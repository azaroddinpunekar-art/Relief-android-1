package com.relief.app.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.relief.app.data.ai.WisdomAssistantResponse
import com.relief.app.data.local.entity.BookEntity
import com.relief.app.data.local.entity.ImportAuditEntity
import com.relief.app.data.local.entity.PassageEntity
import com.relief.app.data.model.AppLanguage
import com.relief.app.data.model.ScriptureType
import com.relief.app.data.model.SituationGuidanceSpec
import com.relief.app.data.preferences.UserPreferencesRepository
import com.relief.app.data.preferences.UserSettings
import com.relief.app.data.repository.ReliefRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ReliefViewModel(
    private val repository: ReliefRepository,
    private val preferences: UserPreferencesRepository
) : ViewModel() {

    val settings: StateFlow<UserSettings> = preferences.settings.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = UserSettings()
    )

    val quranBooks: StateFlow<List<BookEntity>> = repository.observeBooks(ScriptureType.QURAN)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val gitaBooks: StateFlow<List<BookEntity>> = repository.observeBooks(ScriptureType.GITA)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bibleBooks: StateFlow<List<BookEntity>> = repository.observeBooks(ScriptureType.BIBLE)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bookmarks: StateFlow<List<PassageEntity>> = repository.observeBookmarks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bookmarkIds: StateFlow<List<String>> = repository.observeBookmarkIds()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val readingHistory: StateFlow<List<PassageEntity>> = repository.observeHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val importAudits: StateFlow<List<ImportAuditEntity>> = repository.observeAudits()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _dailyWisdom = MutableStateFlow<PassageEntity?>(null)
    val dailyWisdom: StateFlow<PassageEntity?> = _dailyWisdom.asStateFlow()

    private val _searchResults = MutableStateFlow<List<PassageEntity>>(emptyList())
    val searchResults: StateFlow<List<PassageEntity>> = _searchResults.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    private val _importStatusMessage = MutableStateFlow<String?>(null)
    val importStatusMessage: StateFlow<String?> = _importStatusMessage.asStateFlow()

    private val _assistantResponse = MutableStateFlow<WisdomAssistantResponse?>(null)
    val assistantResponse: StateFlow<WisdomAssistantResponse?> = _assistantResponse.asStateFlow()

    init {
        refreshDailyWisdom()
    }

    fun refreshDailyWisdom() {
        viewModelScope.launch {
            _dailyWisdom.value = repository.getDailyWisdom()
        }
    }

    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch { preferences.setLanguage(language) }
    }

    fun completeOnboarding() {
        viewModelScope.launch { preferences.completeOnboarding() }
    }

    fun setFontScale(scale: Float) {
        viewModelScope.launch { preferences.setFontScale(scale) }
    }

    fun setShowTransliteration(enabled: Boolean) {
        viewModelScope.launch { preferences.setShowTransliteration(enabled) }
    }

    fun observeChapter(scripture: ScriptureType, bookNumber: Int, chapterNumber: Int) =
        repository.observeChapter(scripture, bookNumber, chapterNumber)

    fun toggleBookmark(passageId: String) {
        viewModelScope.launch { repository.toggleBookmark(passageId) }
    }

    fun recordReading(passageId: String) {
        viewModelScope.launch { repository.recordReading(passageId) }
    }

    fun clearHistory() {
        viewModelScope.launch { repository.clearReadingHistory() }
    }

    fun search(query: String, scripture: ScriptureType?) {
        viewModelScope.launch {
            _isSearching.value = true
            _searchResults.value = repository.search(query, scripture)
            _isSearching.value = false
        }
    }

    fun importDataset(scripture: ScriptureType, uri: Uri) {
        viewModelScope.launch {
            runCatching {
                repository.importDatasetFromUri(scripture, uri)
            }.onSuccess { audit ->
                _importStatusMessage.value =
                    "${scripture.displayNameEn}: ${audit.importedPassages}/${audit.expectedPassages} imported"
                refreshDailyWisdom()
            }.onFailure { err ->
                _importStatusMessage.value = err.message ?: "Dataset import failed."
            }
        }
    }

    fun getAllSituations(): List<SituationGuidanceSpec> = repository.getAllSituations()

    fun getSituation(id: String): SituationGuidanceSpec? = repository.getSituationById(id)

    suspend fun loadPassagesByIds(ids: List<String>): Map<String, PassageEntity> =
        repository.getPassagesForIds(ids)

    fun askWisdomAssistant(question: String) {
        viewModelScope.launch {
            _assistantResponse.value = repository.askWisdomAssistant(question)
        }
    }
}

class ReliefViewModelFactory(
    private val repository: ReliefRepository,
    private val preferences: UserPreferencesRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return ReliefViewModel(repository, preferences) as T
    }
}
