package com.relief.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val ReliefDarkScheme = darkColorScheme(
    primary = MetallicGold,
    onPrimary = DeepObsidian,
    primaryContainer = ElevatedCharcoal,
    onPrimaryContainer = HighlightGold,
    secondary = WarmGrey,
    onSecondary = DeepObsidian,
    background = DeepObsidian,
    onBackground = WarmWhite,
    surface = CharcoalSurface,
    onSurface = WarmWhite,
    surfaceVariant = ElevatedCharcoal,
    onSurfaceVariant = WarmGrey,
    outline = HairlineCharcoal,
    error = SoftCrimson
)

@Composable
fun ReliefTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = ReliefDarkScheme,
        typography = ReliefTypography,
        content = content
    )
}
