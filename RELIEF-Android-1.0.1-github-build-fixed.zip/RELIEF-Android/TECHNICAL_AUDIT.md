# RELIEF technical audit and controlled update

## Scope
This update preserves the existing Kotlin, Jetpack Compose, Room, navigation, UI, and scripture JSON assets. It changes dataset validation/reporting only and adds a unit test.

## Source dataset inspection (2026-11-25)
- Quran: 114 books/surahs, 6,236 passages; no blank original, English, or Hindi text found; no duplicate IDs or coordinates found.
- Bhagavad Gita: 18 chapter records, 701 passages; no blank original, English, or Hindi text found; no duplicate IDs or coordinates found. The app's configured canonical total is 700. The 701st record has not been removed or reclassified. The source edition/numbering convention must be confirmed before changing the expected total.
- Bible: 66 books, 31,102 passages; 134 passages have blank original-language text; no blank English or Hindi text found; no duplicate IDs or coordinates found.

## Changes in this package
- Validator now counts missing original-language, English, and Hindi text separately.
- Missing-field messages identify the exact field and passage ID.
- Book and total passage count mismatches are reported whether under or over the configured expected count.
- Import audit summary reports separate missing-text totals and up to 100 detail lines.
- Added a unit test covering separate missing-field counts and count mismatch reporting.

## Deliberately not changed
- No scripture text was generated, guessed, or altered.
- No Gita passage was deleted.
- No Bible original-language text was fabricated.
- UI and app architecture were not redesigned.

## Validation limitation
This environment does not have Gradle installed, so Android compilation and JUnit execution have not been run here. Run `gradle testDebugUnitTest assembleDebug` in GitHub Actions after uploading this package. A green build is required before installing the replacement APK.
