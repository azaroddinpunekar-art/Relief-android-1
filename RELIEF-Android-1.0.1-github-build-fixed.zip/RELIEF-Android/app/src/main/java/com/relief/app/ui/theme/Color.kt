package com.relief.app.ui.theme

import androidx.compose.ui.graphics.Color

val DeepObsidian = Color(0xFF0B0B0D)
val CharcoalSurface = Color(0xFF131317)
val ElevatedCharcoal = Color(0xFF1A1A20)
val HairlineCharcoal = Color(0xFF282832)

val MetallicGold = Color(0xFFC6A769)
val HighlightGold = Color(0xFFD8BE87)
val MutedGoldBorder = Color(0x33C6A769)

val WarmWhite = Color(0xFFF3EFE6)
val WarmGrey = Color(0xFFA19C92)
val MutedGrey = Color(0xFF6E6A63)

val SoftEmerald = Color(0xFF6F9F87)
val SoftAmber = Color(0xFFD1A054)
val SoftCrimson = Color(0xFFC46D6D)
